==========================================
        UXNTWWW SYSTEM TOOLKIT v1.0
==========================================

📌 WHAT IS THIS:
A simple tool to clean your PC from junk, cache, and reset network settings.

🔧 WHAT IT DOES:
[1] Clean Temp + %Temp% — removes temporary files from your system and user folders.
[2] Clear browser cache — clears cache for Chrome, Edge, Firefox, Opera, Yandex.
[3] Reset DNS and Netsh — resets DNS cache, renews IP, resets TCP/IP and Winsock.

🚀 HOW TO USE (READ CAREFULLY):
1. EXTRACT the archive (UNZIP it) to a folder on your desktop.
2. Right-click on "Ux-WPC.vbs" and select "Run as administrator".
3. In the menu, press [1], [2], or [3] and hit Enter.
4. For option [3], the PC will ask you to restart — press Y to restart now or N to do it later.

⚠️ IMPORTANT:
- Do NOT run the script from inside the ZIP archive — it will NOT work.
- Only run "Ux-WPC.vbs" after extracting all files to a folder.
- The script will request administrator privileges automatically.

📧 Questions? Contact: https://uxntwww.github.io

==========================================
        UXNTWWW СИСТЕМНЫЙ НАБОР v1.0
==========================================

📌 ЧТО ЭТО:
Простая утилита для очистки ПК от мусора, кэша и сброса настроек сети.

🔧 ЧТО ОНА ДЕЛАЕТ:
[1] Очистка Temp + %Temp% — удаляет временные файлы из системной папки и папки пользователя.
[2] Сброс кэша браузеров — очищает кэш для Chrome, Edge, Firefox, Opera, Yandex.
[3] Сброс DNS и Netsh — сбрасывает DNS-кэш, обновляет IP, сбрасывает TCP/IP и Winsock.

🚀 КАК ПОЛЬЗОВАТЬСЯ (ЧИТАЙТЕ ВНИМАТЕЛЬНО):
1. РАСПАКУЙТЕ архив (ИЗВЛЕКИТЕ) в папку на рабочем столе.
2. Нажмите правой кнопкой на "Ux-WPC.vbs" и выберите "Запустить от имени администратора".
3. В меню нажмите [1], [2] или [3] и нажмите Enter.
4. Для пункта [3] ПК спросит о перезагрузке — нажмите Y, чтобы перезагрузить сейчас, или N, чтобы сделать это позже.

⚠️ ВАЖНО:
- НЕ запускайте скрипт прямо из ZIP-архива — он НЕ сработает.
- Запускайте "Ux-WPC.vbs" ТОЛЬКО после распаковки всех файлов в папку.
- Скрипт автоматически запросит права администратора.

📧 Вопросы? Пишите: https://uxntwww.github.io

==========================================