@echo off
:: Check admin rights
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

title UXNTWWW System Toolkit
color 0A
:: Check for updates
echo [UXNT] Checking for updates...
set "site_url=https://uxntwww.github.io"
set "remote_version="
for /f "delims=" %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "try { (Invoke-WebRequest -Uri '%site_url%/version.txt' -UseBasicParsing -TimeoutSec 5).Content.Trim() } catch { }" 2^>nul') do set "remote_version=%%A"

if "%remote_version%"=="" goto menu
if "%remote_version%"=="1.0" goto menu

cls
echo ==========================================
echo       NEW UPDATE AVAILABLE! (v%remote_version%)
echo ==========================================
echo.
echo   A newer version of UXNTWWW System Toolkit is out.
echo   Please visit the website to download the update.
echo.
echo   URL: %site_url%
echo.
echo ==========================================
echo.
pause >nul
goto menu
:menu
cls
echo ==========================================
echo       UXNTWWW SYSTEM TOOLKIT v1.0
echo ==========================================
echo.
echo   [0] Exit
echo   [1] Clean Temp + %%Temp%%
echo   [2] Clear browser cache
echo   [3] Reset DNS and Netsh (Internet)
echo.
echo ==========================================
set /p choice="Select option (0-3): "

if "%choice%"=="0" goto exit
if "%choice%"=="1" goto clean_temp
if "%choice%"=="2" goto clear_browser_cache
if "%choice%"=="3" goto reset_network
goto menu

:clean_temp
cls
echo.
echo [UXNT] Cleaning temporary files...
del /f /s /q "%temp%\*.*" 2>nul
del /f /s /q "C:\Windows\Temp\*.*" 2>nul
echo [UXNT] Done! Temporary files removed.
pause >nul
goto menu

:clear_browser_cache
cls
echo.
echo [UXNT] Clearing browser cache...
if exist "%localappdata%\Google\Chrome\User Data\Default\Cache" rd /s /q "%localappdata%\Google\Chrome\User Data\Default\Cache" >nul 2>&1 && echo   Chrome - cleaned
if exist "%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache" rd /s /q "%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache" >nul 2>&1 && echo   Yandex Browser - cleaned
if exist "%localappdata%\Microsoft\Edge\User Data\Default\Cache" rd /s /q "%localappdata%\Microsoft\Edge\User Data\Default\Cache" >nul 2>&1 && echo   Edge - cleaned
if exist "%appdata%\Mozilla\Firefox\Profiles" (
    for /d %%i in ("%appdata%\Mozilla\Firefox\Profiles\*") do (
        if exist "%%i\cache2" rd /s /q "%%i\cache2" >nul 2>&1 && echo   Firefox - cleaned
    )
)
if exist "%localappdata%\Programs\Opera GX\cache" rd /s /q "%localappdata%\Programs\Opera GX\cache" >nul 2>&1 && echo   Opera GX - cleaned
if exist "%localappdata%\Programs\Opera\cache" rd /s /q "%localappdata%\Programs\Opera\cache" >nul 2>&1 && echo   Opera - cleaned
echo [UXNT] Done! Browser cache cleared.
pause >nul
goto menu

:reset_network
cls
echo.
echo [UXNT] Resetting network settings...
ipconfig /flushdns >nul 2>&1
ipconfig /release >nul 2>&1
ipconfig /renew >nul 2>&1
netsh int ip reset >nul 2>&1
netsh winsock reset >nul 2>&1
echo [UXNT] Done! Network reset complete.
echo.
echo [UXNT] System restart is recommended.
echo.
choice /C YN /M "Restart computer now"
if errorlevel 2 goto no_reboot
if errorlevel 1 goto reboot

:reboot
echo [UXNT] Restarting...
shutdown /r /t 3 /c "UXNTWWW: Restarting in 3 seconds..."
exit

:no_reboot
echo [UXNT] Restart canceled. Please restart later for full effect.
pause >nul
goto menu

:exit
exit