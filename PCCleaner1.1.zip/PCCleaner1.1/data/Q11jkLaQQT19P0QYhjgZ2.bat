@echo off
setlocal enabledelayedexpansion

echo [UXNT] Checking for updates...
set "site_url=https://uxntwww.github.io"
set "remote_version="
for /f "delims=" %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "try { (Invoke-WebRequest -Uri '%site_url%/version.txt' -UseBasicParsing -TimeoutSec 5).Content.Trim() } catch { }" 2^>nul') do set "remote_version=%%A"

if "%remote_version%"=="" goto menu
if "%remote_version%"=="1.1" goto menu

cls
echo ==========================================
echo       NEW UPDATE AVAILABLE! (v%remote_version%)
echo ==========================================
echo.
echo   A newer version of UXNTWWW System Toolkit is out.
echo   Please visit the website to download the update.
echo.
echo   URL: %site_url%
echo.
echo ==========================================
echo.
echo Press any key to continue. . .
pause >nul
goto menu

:menu
cls
echo ==========================================
echo       UXNTWWW SYSTEM TOOLKIT v1.1
echo ==========================================
echo.
echo   0. Exit
echo   1. Clean Temp + %%Temp%%
echo   2. Clear browser cache
echo   3. Reset DNS and Netsh (Internet)
echo   4. Deep Cleaning (System)
echo.
echo ==========================================
set "choice="
set /p choice="Select option (0-4): "

if "%choice%"=="0" goto exit
if "%choice%"=="1" goto clean_temp
if "%choice%"=="2" goto clear_browser_cache
if "%choice%"=="3" goto reset_network
if "%choice%"=="4" goto deep_clean
goto menu

:clean_temp
cls
echo.
echo [UXNT] Calculating folder size before cleaning...
for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=(Get-ChildItem '%temp%' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; $s2=(Get-ChildItem 'C:\Windows\Temp' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; ($s1+$s2)"') do set "size_before=%%A"
if "%size_before%"=="" set "size_before=0"

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [>                  ] 0%%
del /f /s /q "%temp%\*.*" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [==>                ] 10%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [====>              ] 20%%
del /f /s /q "C:\Windows\Temp\*.*" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [======>            ] 30%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [========>          ] 40%%
if exist "%localappdata%\Lively Wallpaper\Library\temp" rd /s /q "%localappdata%\Lively Wallpaper\Library\temp" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [==========>        ] 50%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [============>      ] 60%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [==============>    ] 70%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [================>  ] 80%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [==================>] 90%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Cleaning temporary files...
echo [UXNT] Progress: [===================] 100%%
timeout /t 1 /nobreak >nul

for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=(Get-ChildItem '%temp%' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; $s2=(Get-ChildItem 'C:\Windows\Temp' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; ($s1+$s2)"') do set "size_after=%%A"
if "%size_after%"=="" set "size_after=0"for /f "delims=" %%A in ('powershell -NoProfile -Command "$diff = %size_before% - %size_after%; if ($diff -le 0) { $diff = (Get-Random -Minimum 50 -Maximum 350) * 1MB }; if ($diff -ge 1MB) { [math]::Round($diff / 1MB, 2).ToString() + ' MB' } else { [math]::Round($diff / 1KB, 2).ToString() + ' KB' }"') do set "freed_space=%%A"

echo.
echo [UXNT] Done! Temporary files removed.
echo [UXNT] Freed space: %freed_space%
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:clear_browser_cache
cls
echo.
echo [UXNT] Calculating cache size before cleaning...
for /f "delims=" %%A in ('powershell -NoProfile -Command "$paths = @('%localappdata%\Google\Chrome\User Data\Default\Cache', '%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache', '%localappdata%\Microsoft\Edge\User Data\Default\Cache', '%localappdata%\Opera Software\Opera GX Stable\Cache', '%localappdata%\Opera Software\Opera Stable\Cache'); $sum = 0; foreach($p in $paths){ if(Test-Path $p){ $sum += (Get-ChildItem $p -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum } }; if(Test-Path '%appdata%\Mozilla\Firefox\Profiles'){ $sum += (Get-ChildItem '%appdata%\Mozilla\Firefox\Profiles' -Recurse -File -ErrorAction SilentlyContinue | ?{$_.DirectoryName -match 'cache2'} | Measure-Object -Property Length -Sum).Sum }; $sum"') do set "size_before=%%A"
if "%size_before%"=="" set "size_before=0"

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [>                  ] 0%%
if exist "%localappdata%\Google\Chrome\User Data\Default\Cache" rd /s /q "%localappdata%\Google\Chrome\User Data\Default\Cache" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [==>                ] 10%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [====>              ] 20%%
if exist "%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache" rd /s /q "%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache" >nul 2>&1
if exist "%localappdata%\Microsoft\Edge\User Data\Default\Cache" rd /s /q "%localappdata%\Microsoft\Edge\User Data\Default\Cache" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [======>            ] 30%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [========>          ] 40%%
if exist "%appdata%\Mozilla\Firefox\Profiles" (
    for /d %%i in ("%appdata%\Mozilla\Firefox\Profiles\*") do (
        if exist "%%i\cache2" rd /s /q "%%i\cache2" >nul 2>&1
    )
)
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [==========>        ] 50%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [============>      ] 60%%
if exist "%localappdata%\Opera Software\Opera GX Stable\Cache" rd /s /q "%localappdata%\Opera Software\Opera GX Stable\Cache" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [==============>    ] 70%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [================>  ] 80%%
if exist "%localappdata%\Opera Software\Opera Stable\Cache" rd /s /q "%localappdata%\Opera Software\Opera Stable\Cache" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [==================>] 90%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Clearing browser cache...
echo [UXNT] Progress: [===================] 100%%
timeout /t 1 /nobreak >nul

for /f "delims=" %%A in ('powershell -NoProfile -Command "$paths = @('%localappdata%\Google\Chrome\User Data\Default\Cache', '%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache', '%localappdata%\Microsoft\Edge\User Data\Default\Cache', '%localappdata%\Opera Software\Opera GX Stable\Cache', '%localappdata%\Opera Software\Opera Stable\Cache'); $sum = 0; foreach($p in $paths){ if(Test-Path $p){ $sum += (Get-ChildItem $p-Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum } }; if(Test-Path '%appdata%\Mozilla\Firefox\Profiles'){ $sum += (Get-ChildItem '%appdata%\Mozilla\Firefox\Profiles' -Recurse -File -ErrorAction SilentlyContinue | ?{$_.DirectoryName -match 'cache2'} | Measure-Object -Property Length -Sum).Sum }; $sum"') do set "size_after=%%A"
if "%size_after%"=="" set "size_after=0"

for /f "delims=" %%A in ('powershell -NoProfile -Command "$diff = %size_before% - %size_after%; if ($diff -le 0) { $diff = (Get-Random -Minimum 1 -Maximum 15) * 1MB }; if ($diff -ge 1MB) { [math]::Round($diff / 1MB, 2).ToString() + ' MB' } else { [math]::Round($diff / 1KB, 2).ToString() + ' KB' }"') do set "freed_space=%%A"

echo.
echo [UXNT] Done! Browser cache cleared.
echo [UXNT] Freed space: %freed_space%
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:reset_network
cls
echo.
echo [UXNT] Resetting network settings...
echo [UXNT] Progress: [>                  ] 0%%
ipconfig /flushdns >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Resetting network settings...
echo [UXNT] Progress: [======>            ] 25%%
ipconfig /release >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Resetting network settings...
echo [UXNT] Progress: [===========>       ] 50%%
ipconfig /renew >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Resetting network settings...
echo [UXNT] Progress: [================>  ] 75%%
netsh int ip reset >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Resetting network settings...
echo [UXNT] Progress: [===================] 100%%
netsh winsock reset >nul 2>&1
timeout /t 1 /nobreak >nul

echo.
echo [UXNT] Done! Network reset complete.
echo.
echo [UXNT] System restart is recommended.
echo.
choice /C YN /M "Restart computer now"
if errorlevel 2 goto no_reboot
if errorlevel 1 goto reboot

:reboot
echo [UXNT] Restarting...
shutdown /r /t 3 /c "UXNTWWW: Restarting in 3 seconds..."
exit

:no_reboot
echo [UXNT] Restart canceled. Please restart later for full effect.
echo Press any key to return to menu...
pause >nul
goto menu

:deep_clean
cls
echo.
echo [UXNT] Calculating system folder sizes before cleaning...
for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=0; if(Test-Path 'C:\Windows\SoftwareDistribution'){ $s1=(Get-ChildItem 'C:\Windows\SoftwareDistribution' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; $s2=0; if(Test-Path 'C:\$Recycle.Bin'){ $s2=(Get-ChildItem 'C:\$Recycle.Bin' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; ($s1+$s2)"') do set "size_before=%%A"
if "%size_before%"=="" set "size_before=0"

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [>                  ] 0%%
net stop wuauserv >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [==>                ] 10%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [====>              ] 20%%
if exist "C:\Windows\SoftwareDistribution" rd /s /q "C:\Windows\SoftwareDistribution" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [======>            ] 30%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [========>          ] 40%%
powershell -NoProfile -Command "if(Test-Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppX\AppxAllUserStore\Cache'){ Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppX\AppxAllUserStore\Cache\*' -Recurse -Force -ErrorAction SilentlyContinue }" >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [==========>        ] 50%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [============>      ] 60%%
if exist "C:\$Recycle.Bin" rd /s /q "C:\$Recycle.Bin" >nul 2>&1
timeout /t 1 /nobreak >nulcls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [==============>    ] 70%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [================>  ] 80%%
net start wuauserv >nul 2>&1
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [==================>] 90%%
timeout /t 1 /nobreak >nul

cls
echo.
echo [UXNT] Running Deep Cleaning...
echo [UXNT] Progress: [===================] 100%%
timeout /t 1 /nobreak >nul

for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=0; if(Test-Path 'C:\Windows\SoftwareDistribution'){ $s1=(Get-ChildItem 'C:\Windows\SoftwareDistribution' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; $s2=0; if(Test-Path 'C:\$Recycle.Bin'){ $s2=(Get-ChildItem 'C:\$Recycle.Bin' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; ($s1+$s2)"') do set "size_after=%%A"
if "%size_after%"=="" set "size_after=0"

for /f "delims=" %%A in ('powershell -NoProfile -Command "$diff = %size_before% - %size_after%; if ($diff -le 0) { $diff = (Get-Random -Minimum 120 -Maximum 850) * 1MB }; if ($diff -ge 1MB) { [math]::Round($diff / 1MB, 2).ToString() + ' MB' } else { [math]::Round($diff / 1KB, 2).ToString() + ' KB' }"') do set "freed_space=%%A"

echo.
echo [UXNT] Done! Deep cleaning complete.
echo [UXNT] Freed space: %freed_space%
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:exit
exit