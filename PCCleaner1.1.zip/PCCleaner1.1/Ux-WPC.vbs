Set FSO = CreateObject("Scripting.FileSystemObject")
currentDir = FSO.GetParentFolderName(WScript.ScriptFullName)
Set Shell = CreateObject("Shell.Application")
Shell.ShellExecute "cmd.exe", "/k """ & currentDir & "\data\Q11jkLaQQT19P0QYhjgZ2.bat""", "", "runas", 1
