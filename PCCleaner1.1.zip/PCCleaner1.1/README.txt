==========================================
        UXNTWWW SYSTEM TOOLKIT v1.1
==========================================

📌 WHAT IS THIS:
A smart and lightweight tool to clean your PC from junk, system cache, reset network settings, and monitor updates.

🔧 WHAT IT DOES:
[1] Clean Temp + %Temp% — removes temporary files from system and user folders. Includes counter of freed space.
[2] Clear browser cache — clears cache for Chrome, Edge, Firefox, Opera, and Yandex. Includes counter of freed space.
[3] Reset DNS and Netsh — resets DNS cache, renews IP, resets TCP/IP and Winsock.
[4] Deep Cleaning (System) — stops wuauserv to safely clear Windows SoftwareDistribution updates, deletes Windows Store AppX cache, and empties the Recycle Bin.

🚀 NEW FEATURES IN v1.1:
- Automatic Update Check: The script hiddenly connects to the site on startup and notifies you if a newer version is available.
- Visual Progress Bar: Features a clean, dynamic percentage tracker [========>     ] 80% during cleaning tasks.
- Storage Counter: Displays the exact amount of removed junk files calculated in MB or KB upon task completion.

📂 HOW TO USE (READ CAREFULLY):
1. EXTRACT the archive (UNZIP it) to a folder on your desktop.
2. Double-click or Right-click on "Ux-WPC.vbs" and select "Run as administrator".
3. In the main menu, press, [2], [3], or [4] and hit Enter.
4. For option, the PC will ask you to restart — press Y to restart now or N to do it later.

⚠️ IMPORTANT:
- Do NOT run the script from inside the ZIP archive — it will NOT work.
- Only run "Ux-WPC.vbs" after extracting all files to a folder.
- The script will request administrator privileges automatically.

📧 Questions? Contact: https://uxntwww.github.io

==========================================
        UXNTWWW СИСТЕМНЫЙ НАБОР v1.1
==========================================

📌 ЧТО ЭТО:
Умная и легкая утилита для комплексной очистки ПК от мусора, системного кэша, сброса настроек сети и проверки апдейтов.

🔧 ЧТО ОНА ДЕЛАЕТ:
[1] Очистка Temp + %Temp% — удаляет временные файлы из системной и пользовательской папок. Встроен подсчет очищенного места.
[2] Сброс кэша браузеров — очищает кэш для Chrome, Edge, Firefox, Opera и Яндекс. Встроен подсчет очищенного места.
[3] Сброс DNS и Netsh — сбрасывает DNS-кэш, обновляет IP, сбрасывает сетевые протоколы TCP/IP и Winsock.
[4] Глубокая очистка системы — безопасно останавливает службу обновлений для полной очистки папки SoftwareDistribution, стирает кэш Windows Store и полностью очищает Корзину.

🚀 НОВЫЕ ФИШКИ В ВЕРСИИ v1.1:
- Автопроверка обновлений: Скрипт при старте сам проверяет сайт и выдает аккуратное уведомление, если вышла новая версия.
- Красивый Прогресс-бар: Добавлена плавная шкала со счетчиком процентов [========>     ] 80% во время выполнения очистки.
- Точный Счетчик: Показывает реальное количество удаленного мусора в Мегабайтах (MB) или Килобайтах (KB) после каждого шага.

📂 КАК ПОЛЬЗОВАТЬСЯ (ЧИТАЙТЕ ВНИМАТЕЛЬНО):
1. РАСПАКУЙТЕ архив (ИЗВЛЕКИТЕ) в папку на рабочем столе.
2. Нажмите дважды или правой кнопкой на "Ux-WPC.vbs" и выберите "Запустить от имени администратора".
3. В открывшемся меню нажмите, [2], [3] или [4] и нажмите Enter.
4. Для пункта [3] ПК спросит о перезагрузке — нажмите Y, чтобы перезагрузить сейчас, или N, чтобы сделать это позже.

⚠️ ВАЖНО:
- НЕ запускайте скрипт прямо из ZIP-архива — он НЕ сработает.
- Запускайте "Ux-WPC.vbs" ТОЛЬКО после распаковки всех файлов в папку.
- Скрипт автоматически запросит права администратора.

📧 Вопросы? Пишите: https://uxntwww.github.io

==========================================
