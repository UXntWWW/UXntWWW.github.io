@echo off
title UXWEditor Launcher

:: ===== 1. Админ-права и сохранение директории =====
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting admin rights...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
set "CURRENT_DIR=%cd%\"

:: ===== 2. Поиск .exe файла =====
set "EXE_PATH="
for %%f in ("%CURRENT_DIR%*.exe") do (
    set "EXE_PATH=%%f"
)

if not defined EXE_PATH (
    echo Error: No .exe file found in %CURRENT_DIR%
    pause
    exit /b 1
)

:: ===== 3. Определение рабочего стола =====
if exist "%USERPROFILE%\OneDrive\Desktop" (
    set "DESKTOP=%USERPROFILE%\OneDrive\Desktop"
) else (
    set "DESKTOP=%USERPROFILE%\Desktop"
)
set "SHORTCUT=%DESKTOP%\UXWEditor.lnk"

:: ===== 4. Поиск иконки =====
if exist "%CURRENT_DIR%Resources\icon.ico" (
    set "ICON=%CURRENT_DIR%Resources\icon.ico"
) else if exist "%CURRENT_DIR%icon.ico" (
    set "ICON=%CURRENT_DIR%icon.ico"
) else (
    set "ICON="
)

:: ===== 5. Создание ярлыка через PowerShell =====
echo Creating desktop shortcut...
set "PS_EXE=%EXE_PATH:\=\\%"
set "PS_DIR=%CURRENT_DIR:\=\\%"
set "PS_SHORTCUT=%SHORTCUT:\=\\%"
set "PS_ICON=%ICON:\=\\%"

if "%ICON%"==="" (
    powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%PS_SHORTCUT%'); $Shortcut.TargetPath = '%PS_EXE%'; $Shortcut.WorkingDirectory = '%PS_DIR%'; $Shortcut.Description = 'UXWEditor'; $Shortcut.Save()"
) else (
    powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%PS_SHORTCUT%'); $Shortcut.TargetPath = '%PS_EXE%'; $Shortcut.WorkingDirectory = '%PS_DIR%'; $Shortcut.Description = 'UXWEditor'; $Shortcut.IconLocation = '%PS_ICON%'; $Shortcut.Save()"
)
echo Shortcut created.

:: ===== 6. Принудительная установка/обновление ассоциации =====
echo Installing/Updating .uxw association...
reg add "HKEY_CLASSES_ROOT\.uxw" /ve /t REG_SZ /d "UXWEditor.Document" /f >nul 2>&1
reg add "HKEY_CLASSES_ROOT\UXWEditor.Document" /ve /t REG_SZ /d "UXWEditor Document" /f >nul 2>&1
reg add "HKEY_CLASSES_ROOT\UXWEditor.Document\DefaultIcon" /ve /t REG_SZ /d "%EXE_PATH%,0" /f >nul 2>&1
reg add "HKEY_CLASSES_ROOT\UXWEditor.Document\shell\open\command" /ve /t REG_SZ /d "\"%EXE_PATH%\" \"%%1\"" /f >nul 2>&1
echo Association installed/updated successfully.

:: ===== 7. Автоматическое создание файла uninstall.bat =====
echo Generating uninstaller...
(
echo @echo off
echo title UXWEditor Uninstaller
echo net session ^>nul 2^>^&1
echo if %%errorlevel%% neq 0 ^(
echo     powershell -Command "Start-Process '%%~f0' -Verb RunAs"
echo     exit /b
echo ^)
echo echo Removing .uxw file associations...
echo reg delete "HKEY_CLASSES_ROOT\.uxw" /f ^>nul 2^>^&1
echo reg delete "HKEY_CLASSES_ROOT\UXWEditor.Document" /f ^>nul 2^>^&1
echo if exist "%SHORTCUT%" del /f /q "%SHORTCUT%" ^>nul 2^>^&1
echo ie4uinit.exe -show ^>nul 2^>^&1
echo echo Uninstallation finished.
echo del "%%~f0" ^& exit
) > "%CURRENT_DIR%uninstall.bat"

:: ===== 8. Запуск приложения =====
echo Launching UXWEditor...
start "" "%EXE_PATH%"
exit
