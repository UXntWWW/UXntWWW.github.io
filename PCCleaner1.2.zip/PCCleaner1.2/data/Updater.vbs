Dim answer, fso, shell, currentPath, http, stream
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

answer = MsgBox("Do you want update your program? Press Enter to update.", vbOKCancel, "PCCleaner Installer")

If answer = vbCancel Then
    WScript.Quit
End If

currentPath = fso.GetParentFolderName(WScript.ScriptFullName)

shell.Run "cmd /c rmdir /s /q """ & currentPath & "\*.*""", 0, True

Set http = CreateObject("MSXML2.XMLHTTP")
http.Open "GET", "https://github.com/UXntWWW/UXntWWW.github.io/raw/main/PCCleaner.zip", False
http.Send

Set stream = CreateObject("ADODB.Stream")
stream.Type = 1
stream.Open
stream.Write http.responseBody
stream.SaveToFile currentPath & "\PCCleaner.zip", 2
stream.Close

shell.Run "powershell -command Expand-Archive -Path '" & currentPath & "\PCCleaner.zip' -DestinationPath '" & currentPath & "' -Force", 0, True

shell.Run "wscript.exe " & currentPath & "\Ux-WPC.vbs", 0, False

fso.DeleteFile WScript.ScriptFullName