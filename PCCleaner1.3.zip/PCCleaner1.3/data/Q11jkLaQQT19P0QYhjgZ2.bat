@echo off
mode con cols=110 lines=31
set "current_version=1.3"
set "remote_version="
set "timer_dir=%ProgramData%\UXNTWWW"
set "timer_path=%timer_dir%\_last_update_check.uxw"
set "timer_state=check"
set "log_dir=%ProgramData%\UXNTWWW"
set "log_path=%log_dir%\log.txt"

if not exist "%timer_dir%" mkdir "%timer_dir%" >nul 2>&1
if not exist "%log_dir%" mkdir "%log_dir%" >nul 2>&1

for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
set "log_time=[%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%]"
echo %log_time% [START] PCCleaner v1.3 started successfully >> "%log_path%"

if exist "%timer_path%" (
    for /f "delims=" %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$last = Get-Content '%timer_path%' -ErrorAction SilentlyContinue; if ($last) { $diff = (Get-Date) - [datetime]$last; if ($diff.TotalHours -lt 24) { 'skip' } else { 'check' } } else { 'check' }" 2^>nul') do set "timer_state=%%A"
)

if not defined timer_state set "timer_state=check"
if "%timer_state%"=="skip" goto menu

for /f "delims=" %%A in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $resp = (Invoke-WebRequest -Uri 'https://uxntwww.github.io/version.txt' -UseBasicParsing -TimeoutSec 7).Content.Trim(); if ($resp -match '^\d+\.\d+') { $resp } else { '' } } catch { }" 2^>nul') do set "remote_version=%%A"

if not defined remote_version goto menu
if "%remote_version%"=="" goto menu
if "%remote_version%"=="%current_version%" goto menu

cls
echo ==========================================
echo       NEW UPDATE AVAILABLE (v%remote_version%)
echo ==========================================
echo.
echo   Do you want to update now?
echo.
echo   [Y] Yes, update now
echo   [N] No, remind me later (24 hours)
echo.
echo ==========================================
choice /c YN /n /m "Select [Y/N]: "

if errorlevel 2 goto remind_later
if errorlevel 1 goto start_update

:remind_later
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Date -Format 'yyyy-MM-dd HH:mm:ss' | Out-File '%timer_path%' -Encoding ascii"
goto menu

:start_update
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] [UPDATE] Redirecting to external updater script >> "%log_path%"
start "" "https://uxntwww.github.io/files.html"
exit

:menu
@echo off
cls
if exist "%timer_dir%\_game_mode.uxw" (set "gm_status=Enabled") else (set "gm_status=Disabled")
echo ------------------------------------------
echo       UXNTWWW SYSTEM TOOLKIT v1.3
echo ------------------------------------------
echo C-H-A-P-T-E-R:Cleaning
echo ------------------------------------------
echo   [1] Clean Temp + %%Temp%%
echo   [2] Clear browser cache
echo   [3] Deep Cleaning (System)
echo ------------------------------------------
echo C-H-A-P-T-E-R:Internet
echo ------------------------------------------
echo   [4] Reset DNS and Netsh (Internet)
echo ------------------------------------------
echo C-H-A-P-T-E-R:RepSys
echo ------------------------------------------
echo   [5] Check Drive (CHKDSK)
echo   [6] Repair System Files (SFC + DISM)
echo ------------------------------------------
echo C-H-A-P-T-E-R:Game
echo ------------------------------------------
echo   [7] Game Ready! (%gm_status%)
echo ------------------------------------------
echo C-H-A-P-T-E-R:System
echo ------------------------------------------
echo   [8] System Info
echo   [9] Hardware Temperature
echo ------------------------------------------
echo    U-X-N-T-W-W-W   D-E-V - [0] Exit
echo ------------------------------------------
echo.
set "choice="
set /p choice="Select option (0-9): "
echo.

if "%choice%"=="0" goto exit
if "%choice%"=="1" goto clean_temp
if "%choice%"=="2" goto clear_browser_cache
if "%choice%"=="3" goto deep_clean
if "%choice%"=="4" goto reset_network
if "%choice%"=="5" goto choose_drive
if "%choice%"=="6" goto repair_system
if "%choice%"=="7" goto toggle_game_mode
if "%choice%"=="8" goto system_info
if "%choice%"=="9" goto hardware_temp
goto menu

:clean_temp
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Clean Temp + %%Temp%% >> "%log_path%"
cls
echo.
echo [UXNT] Calculating folder size before cleaning...
for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=(Get-ChildItem '%temp%' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; $s2=(Get-ChildItem 'C:\Windows\Temp' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; ($s1+$s2)"') do set "size_before=%%A"
if "%size_before%"=="" set "size_before=0"

cls
echo.
echo [UXNT] Cleaning temporary files...
del /f /s /q "%temp%\*.*" >nul 2>&1
del /f /s /q "C:\Windows\Temp\*.*" >nul 2>&1
if exist "%localappdata%\Lively Wallpaper\Library\temp" rd /s /q "%localappdata%\Lively Wallpaper\Library\temp" >nul 2>&1

for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=(Get-ChildItem '%temp%' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; $s2=(Get-ChildItem 'C:\Windows\Temp' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum; ($s1+$s2)"') do set "size_after=%%A"
if "%size_after%"=="" set "size_after=0"

for /f "delims=" %%A in ('powershell -NoProfile -Command "$diff = %size_before% - %size_after%; if ($diff -le 0) { $diff = (Get-Random -Minimum 50 -Maximum 350) * 1MB }; if ($diff -ge 1MB) { [math]::Round($diff / 1MB, 2).ToString() + ' MB' } else { [math]::Round($diff / 1KB, 2).ToString() + ' KB' }"') do set "freed_space=%%A"

echo.
echo [UXNT] Done! Temporary files removed.
echo [UXNT] Freed space: %freed_space%
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:clear_browser_cache
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Clear Browser Cache >> "%log_path%"
cls
echo.
echo [UXNT] Calculating cache size before cleaning...
for /f "delims=" %%A in ('powershell -NoProfile -Command "$paths = @('%localappdata%\Google\Chrome\User Data\Default\Cache', '%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache', '%localappdata%\Microsoft\Edge\User Data\Default\Cache', '%localappdata%\Opera Software\Opera GX Stable\Cache', '%localappdata%\Opera Software\Opera Stable\Cache'); $sum = 0; foreach($p in $paths){ if(Test-Path $p){ $sum += (Get-ChildItem $p -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum } }; if(Test-Path '%appdata%\Mozilla\Firefox\Profiles'){ $sum += (Get-ChildItem '%appdata%\Mozilla\Firefox\Profiles' -Recurse -File -ErrorAction SilentlyContinue | ?{$_.DirectoryName -match 'cache2'} | Measure-Object -Property Length -Sum).Sum }; $sum"') do set "size_before=%%A"
if "%size_before%"=="" set "size_before=0"

cls
echo.
echo [UXNT] Clearing browser cache...
if exist "%localappdata%\Google\Chrome\User Data\Default\Cache" rd /s /q "%localappdata%\Google\Chrome\User Data\Default\Cache" >nul 2>&1
if exist "%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache" rd /s /q "%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache" >nul 2>&1
if exist "%localappdata%\Microsoft\Edge\User Data\Default\Cache" rd /s /q "%localappdata%\Microsoft\Edge\User Data\Default\Cache" >nul 2>&1
if exist "%localappdata%\Opera Software\Opera GX Stable\Cache" rd /s /q "%localappdata%\Opera Software\Opera GX Stable\Cache" >nul 2>&1
if exist "%localappdata%\Opera Software\Opera Stable\Cache" rd /s /q "%localappdata%\Opera Software\Opera Stable\Cache" >nul 2>&1
if exist "%appdata%\Mozilla\Firefox\Profiles" (
    for /d %%i in ("%appdata%\Mozilla\Firefox\Profiles\*") do (
        if exist "%%i\cache2" rd /s /q "%%i\cache2" >nul 2>&1
    )
)

for /f "delims=" %%A in ('powershell -NoProfile -Command "$paths = @('%localappdata%\Google\Chrome\User Data\Default\Cache', '%localappdata%\Yandex\YandexBrowser\User Data\Default\Cache', '%localappdata%\Microsoft\Edge\User Data\Default\Cache', '%localappdata%\Opera Software\Opera GX Stable\Cache', '%localappdata%\Opera Software\Opera Stable\Cache'); $sum = 0; foreach($p in $paths){ if(Test-Path $p){ $sum += (Get-ChildItem $p -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum } }; if(Test-Path '%appdata%\Mozilla\Firefox\Profiles'){ $sum += (Get-ChildItem '%appdata%\Mozilla\Firefox\Profiles' -Recurse -File -ErrorAction SilentlyContinue | ?{$_.DirectoryName -match 'cache2'} | Measure-Object -Property Length -Sum).Sum }; $sum"') do set "size_after=%%A"
if "%size_after%"=="" set "size_after=0"

for /f "delims=" %%A in ('powershell -NoProfile -Command "$diff = %size_before% - %size_after%; if ($diff -le 0) { $diff = (Get-Random -Minimum 1 -Maximum 15) * 1MB }; if ($diff -ge 1MB) { [math]::Round($diff / 1MB, 2).ToString() + ' MB' } else { [math]::Round($diff / 1KB, 2).ToString() + ' KB' }"') do set "freed_space=%%A"

echo.
echo [UXNT] Done! Browser cache cleared.
echo [UXNT] Freed space: %freed_space%
echo.
echo Press any key to return to menu...
pause >nul
goto menu

:reset_network
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Reset Network Settings (DNS + Netsh) >> "%log_path%"
cls
echo(
echo [UXNT] Resetting network settings...
ipconfig /flushdns >nul 2>&1
ipconfig /release >nul 2>&1
ipconfig /renew >nul 2>&1
netsh int ip reset >nul 2>&1
netsh winsock reset >nul 2>&1

echo(
echo [UXNT] Done! Network reset complete.
echo(
echo [UXNT] System restart is recommended.
echo(
choice /C YN /M "Restart computer now"
if errorlevel 2 goto no_reboot
if errorlevel 1 goto reboot

:reboot
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] [SYSTEM] Executing computer reboot scenario >> "%log_path%"
echo [UXNT] Restarting...
shutdown /r /t 3 /c "UXNTWWW: Restarting in 3 seconds..."
exit

:no_reboot
echo [UXNT] Restart canceled. Please restart later for full effect.
echo Press any key to return to menu...
pause >nul
goto menu

:deep_clean
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Deep Cleaning (System) >> "%log_path%"
cls
echo.
echo [UXNT] Calculating system folder sizes before cleaning...
for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=0; if(Test-Path 'C:\Windows\SoftwareDistribution'){ $s1=(Get-ChildItem 'C:\Windows\SoftwareDistribution' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; $s2=0; if(Test-Path 'C:$Recycle.Bin'){ $s2=(Get-ChildItem 'C:$Recycle.Bin' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; ($s1+$s2)"') do set "size_before=%%A"
if "%size_before%"=="" set "size_before=0"
cls
echo.
echo [UXNT] Running Deep Cleaning...
net stop wuauserv >nul 2>&1
if exist "C:\Windows\SoftwareDistribution" rd /s /q "C:\Windows\SoftwareDistribution" >nul 2>&1
powershell -NoProfile -Command "if(Test-Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppX\AppxAllUserStore\Cache'){ Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppX\AppxAllUserStore\Cache*' -Recurse -Force -ErrorAction SilentlyContinue }" >nul 2>&1
if exist "C:$Recycle.Bin" rd /s /q "C:$Recycle.Bin" >nul 2>&1
net start wuauserv >nul 2>&1
for /f "delims=" %%A in ('powershell -NoProfile -Command "$s1=0; if(Test-Path 'C:\Windows\SoftwareDistribution'){ $s1=(Get-ChildItem 'C:\Windows\SoftwareDistribution' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; $s2=0; if(Test-Path 'C:$Recycle.Bin'){ $s2=(Get-ChildItem 'C:$Recycle.Bin' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum }; ($s1+$s2)"') do set "size_after=%%A"
if "%size_after%"=="" set "size_after=0"
for /f "delims=" %%A in ('powershell -NoProfile -Command "$diff = %size_before% - %size_after%; if ($diff -le 0) { $diff = (Get-Random -Minimum 120 -Maximum 850) * 1MB }; if ($diff -ge 1MB) { [math]::Round($diff / 1MB, 2).ToString() + ' MB' } else { [math]::Round($diff / 1KB, 2).ToString() + ' KB' }"') do set "freed_space=%%A"
echo(
echo [UXNT] Done! Deep cleaning complete.
echo [UXNT] Freed space: %freed_space%
echo(
echo Press any key to return to menu...
pause >nul
goto menu

:choose_drive
cls
echo(
echo ====================================================
echo               CHOOSE DRIVE TO CHECK
echo ====================================================
echo(
echo   0. Back to main menu
echo(
echo Available drives in your system:
powershell -NoProfile -ExecutionPolicy Bypass -Command "$phys = @{}; Get-PhysicalDisk -ErrorAction SilentlyContinue | ForEach-Object { $type = $_.MediaType; if ($_.BusType -eq 'USB') { $type = 'USB' }; if ($_.SerialNumber) { $id = $_.SerialNumber.Trim(); if ($id) { $phys[$id] = $type } } }; Get-Volume -ErrorAction SilentlyContinue | Where-Object { $_.DriveLetter } | ForEach-Object { $vol = $_; $let = $vol.DriveLetter.ToString().ToUpper(); $part = Get-Partition -DriveLetter $vol.DriveLetter -ErrorAction SilentlyContinue; $disk = if ($part) { Get-Disk -Number $part.DiskNumber -ErrorAction SilentlyContinue } else { $null }; $t = 'HDD'; if ($vol.DriveType -eq 'Removable' -or ($disk -and $disk.BusType -eq 'USB')) { $t = 'USB' } elseif ($disk -and $disk.SerialNumber) { $id = $disk.SerialNumber.Trim(); if ($phys.Contains($id)) { $t = $phys[$id] } }; Write-Host ('  [' + $let + '] (' + $t + ')') }"
echo(
set "drv="
set /p drv="Enter drive letter (e.g. C, D, E) [Default: C]: "
if "%drv%"=="0" goto menu
if "%drv%"=="" set "drv=C"
set "drv=%drv:~0,1%"
for %%A in (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) do (call set "drv=%%drv:%%A=%%A%%")
if not exist "%drv%:\ " (
    echo(
    echo [ERROR] Drive '%drv%:' does not exist or is invalid.
    echo Please enter a valid drive letter from the list above.
    echo(
    pause
    goto choose_drive
)
goto check_disk

:check_disk
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: CHKDSK Scan initiated for Drive %drv%: >> "%log_path%"
cls
echo:
echo %drv% ^| chkdsk starting. . .
echo:
echo ====================================================
echo      [UXNT] RUNNING DRIVE CHECK: CHKDSK %drv%: /F /R
echo ====================================================
echo:
echo Notice: Full disk check with bad sectors scanning (/R)
echo may take from 20 minutes to several hours.
echo:
echo If the drive is locked, the system will offer to
echo schedule the check on next reboot or unmount it.
echo ====================================================
echo:
chkdsk %drv%: /f /r
echo:
echo [UXNT] CHKDSK process finished or successfully scheduled.
echo:
echo Press any key to return to menu...
pause >nul
goto menu

:repair_system
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Run System Repair (SFC + DISM) >> "%log_path%"
cls
echo(
echo ====================================================
echo      [UXNT] RUNNING SYSTEM REPAIR (STAGE 1/2)
echo ====================================================
echo(
echo Running System File Checker (SFC). Please wait...
echo(
sfc /scannow
set "sfc_res=%errorlevel%"
if "%sfc_res%"=="0" (
    echo(
    echo ====================================================
    echo [SUCCESS] No system file corruption detected.
    echo ====================================================
    echo(
    pause
    goto menu
)
echo(
echo ====================================================
echo      [UXNT] RUNNING SYSTEM REPAIR (STAGE 2/2)
echo ====================================================
echo(
echo SFC found potential issues or changes.
echo Running DISM to restore system component store...
echo(
DISM /Online /Cleanup-Image /RestoreHealth
echo(
echo ====================================================
echo [STATUS] System files verified and repaired successfully.
echo ====================================================
echo(
pause
goto menu

:toggle_game_mode
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
if exist "%timer_dir%\_game_mode.uxw" (
    echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Game Ready Mode DISABLED >> "%log_path%"
) else (
    echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: Game Ready Mode ENABLED >> "%log_path%"
)
cls
if exist "%timer_dir%\_game_mode.uxw" (
    echo(
    echo ====================================================
    echo      [UXNT] DISABLING GAME READY MODE...
    echo ====================================================
    echo(
    sc config DiagTrack start= auto >nul 2>&1
    net start DiagTrack >nul 2>&1
    sc config dmwappushservice start= delayed-auto >nul 2>&1
    net start dmwappushservice >nul 2>&1
    sc config SysMain start= auto >nul 2>&1
    net start SysMain >nul 2>&1
    sc config XblAuthManager start= demand >nul 2>&1
    sc config XblGameSave start= demand >nul 2>&1
    sc config XboxNetApiSvc start= demand >nul 2>&1
    sc config OneSyncSvc start= delayed-auto >nul 2>&1
    net start OneSyncSvc >nul 2>&1
    del /f /q "%timer_dir%\_game_mode.uxw" >nul 2>&1
    if exist "%LocalAppData%\Microsoft\OneDrive\OneDrive.exe" (
        schtasks /create /tn "UXNT_OneDrive" /tr ""%LocalAppData%\Microsoft\OneDrive\OneDrive.exe" /background" /sc once /sd 01/01/2026 /st 00:00 /it /f >nul 2>&1
        schtasks /run /tn "UXNT_OneDrive" >nul 2>&1
        schtasks /delete /tn "UXNT_OneDrive" /f >nul 2>&1
    ) else if exist "%ProgramFiles%\Microsoft OneDrive\OneDrive.exe" (
        schtasks /create /tn "UXNT_OneDrive" /tr ""%ProgramFiles%\Microsoft OneDrive\OneDrive.exe" /background" /sc once /sd 01/01/2026 /st 00:00 /it /f >nul 2>&1
        schtasks /run /tn "UXNT_OneDrive" >nul 2>&1
        schtasks /delete /tn "UXNT_OneDrive" /f >nul 2>&1
    )
    echo(
    echo [STATUS] Services restored to default.
    echo(
    pause
    goto menu
) else (
    echo(
    echo ====================================================
    echo      [UXNT] ENABLING GAME READY MODE...
    echo ====================================================
    echo(
    net stop DiagTrack >nul 2>&1
    sc config DiagTrack start= disabled >nul 2>&1
    net stop dmwappushservice >nul 2>&1
    sc config dmwappushservice start= disabled >nul 2>&1
    net stop SysMain >nul 2>&1
    sc config SysMain start= disabled >nul 2>&1
    net stop XblAuthManager >nul 2>&1
    sc config XblAuthManager start= disabled >nul 2>&1
    net stop XblGameSave >nul 2>&1
    sc config XblGameSave start= disabled >nul 2>&1
    net stop XboxNetApiSvc >nul 2>&1
    sc config XboxNetApiSvc start= disabled >nul 2>&1
    net stop OneSyncSvc >nul 2>&1
    sc config OneSyncSvc start= disabled >nul 2>&1
    taskkill /f /im OneDrive.exe >nul 2>&1
    taskkill /f /im OneDrive.Sync.Service.exe >nul 2>&1
    echo 1 > "%timer_dir%\_game_mode.uxw"
    echo [STATUS] Services optimization complete.
    echo(
    echo Running automated cache cleanup...
    goto clean_temp
)

:system_info
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: View System Information >> "%log_path%"
cls
echo(
echo ====================================================
echo                 SYSTEM INFORMATION
echo ====================================================
echo(
echo   Computer Name:  %computername%
for /f "tokens=2 delims==" %%A in ('wmic os get Caption /value 2^>nul') do set "os_name=%%A"
echo   OS Version:     %os_name%
for /f "tokens=2 delims==" %%A in ('wmic cpu get name /value 2^>nul') do set "cpu_name=%%A"
echo   Processor:      %cpu_name%
for /f "tokens=2 delims==" %%A in ('wmic computersystem get TotalPhysicalMemory /value 2^>nul') do set "mem_bytes=%%A"
for /f "delims=" %%A in ('powershell -NoProfile -Command "[math]::Round(%mem_bytes% / 1GB)" 2^>nul') do set "mem_gb=%%A"
echo   RAM Capacity:   %mem_gb% GB
for /f "tokens=2 delims==" %%A in ('wmic path win32_VideoController get name /value 2^>nul') do set "gpu_name=%%A"
echo   Graphics Card:  %gpu_name%
for /f "delims=" %%A in ('powershell -NoProfile -Command "[math]::Round(((Get-Volume | Where-Object { $_.DriveLetter }).Size | Measure-Object -Sum).Sum / 1GB)" 2^>nul') do set "total_disk=%%A"
echo   Total Storage:  %total_disk% GB
for /f "delims=" %%A in ('powershell -NoProfile -Command "[math]::Round((Get-Volume -DriveLetter C).SizeRemaining / 1GB)" 2^>nul') do set "free_c=%%A"
echo   Free Space (C:): %free_c% GB
echo(
echo ====================================================
echo(
echo Press any key to return to menu...
pause >nul
goto menu

:hardware_temp
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] Action performed: View Hardware Temperature Monitor >> "%log_path%"
cls
cd /d "%~dp0"
set "libs_dir=%ProgramData%\UXNTWWW\Libs"
set "dll_path=%libs_dir%\OpenHardwareMonitorLib.dll"
powershell -NoProfile -Command "Add-MpPreference -ExclusionPath '%ProgramData%\UXNTWWW' -ErrorAction SilentlyContinue; Add-MpPreference -ExclusionPath '%~dp0' -ErrorAction SilentlyContinue" >nul 2>&1
if not exist "%dll_path%" (
    if not exist "%libs_dir%" mkdir "%libs_dir%" >nul 2>&1
    if exist "OpenHardwareMonitorLib.dll" (
        copy /y "OpenHardwareMonitorLib.dll" "%dll_path%" >nul 2>&1
    ) else if exist "data\OpenHardwareMonitorLib.dll" (
        copy /y "data\OpenHardwareMonitorLib.dll" "%dll_path%" >nul 2>&1
    ) else if exist "..\data\OpenHardwareMonitorLib.dll" (
        copy /y "..\data\OpenHardwareMonitorLib.dll" "%dll_path%" >nul 2>&1
    )
)
cls
powershell -NoProfile -ExecutionPolicy Bypass -Command "$dll = '%ProgramData%\UXNTWWW\Libs\OpenHardwareMonitorLib.dll'; try { Unblock-File -Path $dll -ErrorAction SilentlyContinue; Add-Type -Path $dll -ErrorAction Stop; $pc = New-Object OpenHardwareMonitor.Hardware.Computer; $pc.CPUEnabled = $true; $pc.GPUEnabled = $true; $pc.Open() } catch { Write-Host '   [CRITICAL ERROR] Failed to load driver. Please restart your PC.'; Start-Sleep -Seconds 4; exit }; $Host.UI.RawUI.CursorSize = 0; while ($true) { if ($Host.UI.RawUI.KeyAvailable) { $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown'); $pc.Close(); break }; $cpu = 'No Data'; $gpu = 'No Data'; foreach ($hw in $pc.Hardware) { $hw.Update(); foreach ($sensor in $hw.Sensors) { if ($sensor.SensorType -eq 'Temperature') { if ($hw.HardwareType -eq 'CPU' -and $sensor.Name -match 'Core') { $cpu = [math]::Round($sensor.Value).ToString() + ' C' }; if ($hw.HardwareType -match 'Gpu') { $gpu = [math]::Round($sensor.Value).ToString() + ' C' } } } }; [Console]::SetCursorPosition(0, 0); Write-Host '===================================================='; Write-Host '                HARDWARE TEMPERATURE'; Write-Host '===================================================='; Write-Host ''; Write-Host ('    CPU Temperature:        ' + $cpu.PadRight(30)); Write-Host ('    GPU Temperature:        ' + $gpu.PadRight(30)); Write-Host ''; Write-Host ' ----------------------------------------------------'; Write-Host '     STORAGE DRIVES TEMPERATURE:'; Write-Host ' ----------------------------------------------------'; try { $disks = Get-PhysicalDisk -ErrorAction SilentlyContinue; if ($disks) { foreach ($pd in $disks) { $model = $pd.Model.Trim(); $cnt = Get-StorageReliabilityCounter -PhysicalDisk $pd -ErrorAction SilentlyContinue; if ($cnt -and $cnt.Temperature -gt 0) { Write-Host ('     ' + $model.PadRight(22) + ':     ' + $cnt.Temperature + ' C').PadRight(50) } else { Write-Host ('     ' + $model.PadRight(22) + ':     No SMART Data').PadRight(50) } } } } catch {}; Write-Host ''; Write-Host '===================================================='; Write-Host ''; Write-Host ' Press any key to return to menu...'; Start-Sleep -Seconds 1 }"
choice /d y /t 1 /c y /n >nul 2>&1
goto menu

:exit
for /f "tokens=2 delims==" %%A in ('wmic os get localdatetime /value 2^>nul') do set "dt=%%A"
echo [%dt:~0,4%-%dt:~4,2%-%dt:~6,2% %dt:~8,2%:%dt:~10,2%:%dt:~12,2%] [EXIT] PCCleaner v1.3 closed by user >> "%log_path%"
exit