==========================================
        UXNTWWW SYSTEM TOOLKIT v1.3
==========================================

📌 WHAT IS THIS:
A smart and lightweight tool to clean your PC from junk, system cache, reset network settings, and monitor updates.

🔧 WHAT IT DOES:
[1] Clean Temp + %Temp% — removes temporary files from system and user folders. Includes counter of freed space.
[2] Clear browser cache — clears cache for Chrome, Edge, Firefox, Opera, and Yandex. Includes counter of freed space.
[3] Reset DNS and Netsh — resets DNS cache, renews IP, resets TCP/IP and Winsock.
[4] Deep Cleaning (System) — stops wuauserv to safely clear Windows SoftwareDistribution updates, deletes Windows Store AppX cache, and empties the Recycle Bin.
[5] Check Disk (CHKDSK) — scans and fixes disk errors on the system drive (C:).
[6] Game Ready! — optimizes system performance by disabling unnecessary background services (Game Bar, Telemetry, SysMain, etc.).
[7] System File Check (SFC & DISM) — scans and restores corrupted Windows system files using SFC and DISM tools.
[8] System Info — displays detailed information about your PC hardware and operating system.
[9] Temperature Monitor — shows CPU and GPU temperature in real-time using OpenHardwareMonitorLib.
[10] Disk Temperature — shows real-time temperature of all connected drives (HDD/SSD) using a separate method.
[11] Logging — automatically logs all actions and operations to a log file for tracking and troubleshooting.

🚀 NEW FEATURES IN v1.3:
- Temperature Monitor: Real-time CPU and GPU temperature via OpenHardwareMonitorLib.
- Disk Temperature: View real-time temperature of all connected drives (HDD/SSD) using a dedicated method.
- Action Logging: All operations are recorded in a log file for better tracking and debugging.
- Minor improvements and stability fixes.

📂 HOW TO USE (READ CAREFULLY):
1. EXTRACT the archive (UNZIP it) to a folder on your desktop.
2. Double-click on "Ux-WPC.vbs" to launch the toolkit.
3. In the main menu, press the number of the desired option and hit Enter.
4. Follow the on-screen instructions for each tool.

⚠️ IMPORTANT:
- Do NOT run the script from inside the ZIP archive — it will NOT work.
- Only run "Ux-WPC.vbs" after extracting all files to a folder.
- The script will request administrator privileges automatically.

📧 Questions? Contact: https://uxntwww.github.io

==========================================
        UXNTWWW СИСТЕМНЫЙ НАБОР v1.3
==========================================

📌 ЧТО ЭТО:
Умная и легкая утилита для комплексной очистки ПК от мусора, системного кэша, сброса настроек сети и проверки апдейтов.

🔧 ЧТО ОНА ДЕЛАЕТ:
[1] Очистка Temp + %Temp% — удаляет временные файлы из системной и пользовательской папок. Встроен подсчет очищенного места.
[2] Сброс кэша браузеров — очищает кэш для Chrome, Edge, Firefox, Opera и Яндекс. Встроен подсчет очищенного места.
[3] Сброс DNS и Netsh — сбрасывает DNS-кэш, обновляет IP, сбрасывает сетевые протоколы TCP/IP и Winsock.
[4] Глубокая очистка системы — безопасно останавливает службу обновлений для полной очистки папки SoftwareDistribution, стирает кэш Windows Store и полностью очищает Корзину.
[5] Проверка диска (CHKDSK) — сканирует и исправляет ошибки на системном диске (C:).
[6] Игровой режим! — оптимизирует производительность системы, отключая ненужные фоновые службы (Game Bar, телеметрия, SysMain и др.).
[7] Проверка системных файлов (SFC и DISM) — сканирует и восстанавливает поврежденные системные файлы Windows.
[8] Информация о системе — показывает подробные сведения о вашем ПК: процессор, память, видеокарта, диски и версия Windows.
[9] Монитор температуры — показывает температуру ЦП и ГП в реальном времени через OpenHardwareMonitorLib.
[10] Температура дисков — показывает текущую температуру всех подключенных дисков (HDD/SSD) отдельным методом.
[11] Логирование — автоматически записывает все действия в лог-файл для отслеживания и отладки.

🚀 НОВЫЕ ФИШКИ В ВЕРСИИ v1.3:
- Монитор температуры: Температура ЦП и ГП в реальном времени через OpenHardwareMonitorLib.
- Температура дисков: Отдельный метод для просмотра температуры всех накопителей (HDD/SSD) в реальном времени.
- Логирование: Все операции записываются в лог-файл для контроля и анализа.
- Мелкие улучшения и исправления.

📂 КАК ПОЛЬЗОВАТЬСЯ (ЧИТАЙТЕ ВНИМАТЕЛЬНО):
1. РАСПАКУЙТЕ архив (ИЗВЛЕКИТЕ) в папку на рабочем столе.
2. Запустите утилиту двойным кликом по файлу "Ux-WPC.vbs".
3. В открывшемся меню нажмите номер нужного пункта и нажмите Enter.
4. Следуйте инструкциям на экране для каждого инструмента.

⚠️ ВАЖНО:
- НЕ запускайте скрипт прямо из ZIP-архива — он НЕ сработает.
- Запускайте "Ux-WPC.vbs" ТОЛЬКО после распаковки всех файлов в папку.
- Скрипт автоматически запросит права администратора.

📧 Вопросы? Пишите: https://uxntwww.github.io

==========================================